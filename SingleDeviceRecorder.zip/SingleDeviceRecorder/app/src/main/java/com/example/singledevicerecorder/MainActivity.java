package com.example.singledevicerecorder;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.media.AudioFormat;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import java.io.FileInputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private Button mrecordBtn;
    private TextView mrecordLabel;
    private TextView mCamLabel;
    private MediaRecorder recorder;
    private MediaRecorder recorder2;

    private String fileName=null;
    private String fileName2=null;

    public static final String TAG="yashi";
    private ProgressDialog mProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mrecordBtn = findViewById(R.id.record);
        mrecordLabel= findViewById(R.id.textDisplay);

        mProgress = new ProgressDialog(this);

//        fileName = Environment.getExternalStorageDirectory().getAbsolutePath();
//        fileName += "/mainmic.wav";
//        fileName2 = Environment.getExternalStorageDirectory().getAbsolutePath();
//        fileName2 += "/camcordermic.wav";
//
//        mrecordBtn.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                if(event.getAction()==MotionEvent.ACTION_DOWN){
//                    startRecording();
//                    mrecordLabel.setText("Recording Started");
//                  //  mCamLabel.setText("Cam recording on....");
//                }else if(event.getAction()==MotionEvent.ACTION_UP){
//                    stopRecording();
//                    mrecordLabel.setText("Recording Stopped...");
//                  //  mCamLabel.setText("cam recording done");
//
//                }
//
//                return false;
//            }
//        });

    }
//
//    private void startRecording() {
//        recorder = new MediaRecorder();
//        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
//        recorder.setOutputFormat(AudioFormat.ENCODING_PCM_16BIT);
//        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
//        recorder.setAudioChannels(1);
//        recorder.setAudioEncodingBitRate(128000);
//        recorder.setAudioSamplingRate(48000);
//        recorder.setOutputFile(fileName);
//
//        recorder2 = new MediaRecorder();
//        recorder2.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
//        recorder2.setOutputFormat(AudioFormat.ENCODING_PCM_16BIT);
//        recorder2.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
//        recorder2.setAudioChannels(1);
//        recorder2.setAudioEncodingBitRate(128000);
//        recorder2.setAudioSamplingRate(48000);
//        recorder2.setOutputFile(fileName2);
//
//        try {
//            recorder.prepare();
//            recorder2.prepare();
//        } catch (IOException e) {
//            Log.e(TAG, "prepare() failed");
//        }
//
//        recorder.start();
//        try{
//            recorder2.start();
//        }catch (IllegalStateException er){
//            Log.e(TAG, "startRecording: "+er );
//        }
//
//    }


//    private void stopRecording() {
//        recorder.stop();
//        recorder.release();
//
//        try{
//            recorder2.stop();
//            recorder2.release();
//        }catch (IllegalStateException e){
//            Log.e(TAG, "exception" + e );
//        }
//
//        Log.e(TAG, "stopRecording: "+ fileName +"     "+fileName2 );
//        recorder = null;
//        recorder2 = null;
//
//        checkAudio();
//    }

    private void checkAudio() {
        try {
            WaveDecoder decoder = new WaveDecoder(new FileInputStream(fileName));
            FFT fft = new FFT(1024, 48000);
            Log.e(TAG, "checkAudio: "+ fft );
        }catch (Exception e){
            Log.e(TAG, "checkAudio: exception raised"+e );
        }


    }


}

